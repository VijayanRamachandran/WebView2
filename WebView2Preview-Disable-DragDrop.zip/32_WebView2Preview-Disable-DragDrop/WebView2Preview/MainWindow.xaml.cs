﻿
using System;
using System.Windows;

namespace WebView2Preview
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeWebView2Async();
        }

        async void InitializeWebView2Async()
        {
            await webView.EnsureCoreWebView2Async(null);
            
            //webView.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;

            //await webView.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync("window.addEventListener('dragover',function(e){e.preventDefault();},false);");
            //await webView.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync("window.addEventListener('drop',function(e){e.preventDefault();}, false);"); 
        }

        protected override void OnActivated(EventArgs e)
        {
            webView.NavigationStarting += OnWebViewNavigationStarting;
            //webView.NavigationCompleted += OnWebViewNavigationCompleted;        

            base.OnActivated(e);
        }

        protected override void OnDeactivated(EventArgs e)
        {
            webView.NavigationStarting -= OnWebViewNavigationStarting;
            //webView.SourceChanged -= OnWebViewSourceChanged;

            //webView.CoreWebView2.NewWindowRequested -= CoreWebView2_NewWindowRequested;

            base.OnDeactivated(e);
        }

        private void CoreWebView2_NewWindowRequested(object sender, Microsoft.Web.WebView2.Core.CoreWebView2NewWindowRequestedEventArgs e)
        {
            /* webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('dragover',function(e){e.preventDefault();},false);");
            webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('drop',function(e){e.preventDefault();}, false);"); */
        }

        private void OnWebViewNavigationStarting(object sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationStartingEventArgs e)
        {
            webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('dragover',function(e){e.preventDefault();},false);");
            webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('drop',function(e){e.preventDefault();}, false);");
        }

        private void OnWebViewNavigationCompleted(object sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs e)
        {
            /* webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('dragover',function(e){e.preventDefault();},false);");
            webView.CoreWebView2.ExecuteScriptAsync("window.addEventListener('drop',function(e){e.preventDefault();}, false);"); */
        }
    }
}
